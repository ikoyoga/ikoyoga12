def hitungdiskon(pembayaran,diskpersen):
    global totalbayar
    global diskon
    diskon= pembayaran*diskpersen/100
    totalbayar= pembayaran-diskon
    
    pembayaran=int(input("jumlah bayar"))
    diskpersen=int(input("diskon 0..100"))
    hitungdiskon(pembayaran,diskpersen)
    
    print("\n nota pembayaran")
    print ("====================================")
    print("jumlah bayar   =Rp{:15,.2f}".format(pembayaran))
    print("diskon {}%     =Rp{:15,.2f}".format(diskpersen,diskon))
    print("=====================================")
    print("total bayar    =Rp{:15,.2f}".format(totalbayar))