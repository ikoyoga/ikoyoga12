#*****************************
# uas_5180411007.py
# NIM   :518041107
# NAMA  :iko prayoga
#****************************
import mysql.connector
from mysql.connector import Error

konek = mysql.connector.connect(host='localhost',
                                  database='uas',
                                  user='root',
                                  password='')
  
#cek jika terhubung
if konek.is_connected():
  print("terhubung ")
  
cursor = konek.cursor()
sql = "INSERT INTO uas_5180411007 (nik, nama, alamat , tanggal_lahir, jenis_kelamin, agama, status, pekerjaan) VALUES (%s, %s,%s, %s, %s, %s, %s, %s)"
values = [
  ("12342345","Doni", "Jakarta","1999-02-20","laki-laki","islam","belum kawin","petani"),
  ("12342346","wiwik", "palembang","1989-011-20","perempuan","islam","belum kawin","petani"),
  ("12342347","wicak", "Jakarta","1971-02-12","laki-laki","islam","kawin","petani"),
  ("12342348","eka widiawari", "bogor","1981-02-22","perempuan","islam","belum kawin","pns"),
  ("12342349","mawar", "jogja","1990-03-11","perempuan","khatolik","kawin","nelayan"),
  ("12342355","dani", "padang","1991-04-24","laki-laki","budha","kawin","pedagang"),
  ("12342334","widodo", "makasar","1981-02-20","laki-laki","islam","belum kawin","nelayan"),
  ("12342322","nowo", "medan","1972-02-11","laki-laki","konghucu","kawin","pns"),
  ("12342311","prayoga", "lampung","1995-02-22","laki-laki","protestan","kawin","petani"),
  ("12342305","sulastri", "bantul","1994-03-26","perempuan","islam","kawin","tni/polri")
]

for val in values:
  cursor.execute(sql, val)
  konek.commit()

print("{} data ditambahkan".format(len(values)))

#nomer1
sql = "SELECT count(nik) FROM uas_5180411007 WHERE jenis_kelamin='perempuan' AND status='belum kawin' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)

#nomer2
sql = "SELECT count(nik) FROM uas_5180411007 WHERE jenis_kelamin='perempuan' AND agama !='islam' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)

#nomer3  
sql = "SELECT count(nik) FROM uas_5180411007 WHERE pekerjaan='pns' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)


sql = "UPDATE uas_5180411007 SET nama=%s, alamat=%s, tanggal_lahir=%s, jenis_kelamin=%s, agama=%s, status=%s, pekerjaan=%s WHERE nik=%s"
values = [
  ("Doni", "Jakarta","1999-02-20","laki-laki","islam","belum kawin","petani","12342345"),
  ("wiwik", "palembang","1989-011-20","perempuan","islam","belum kawin","petani","12342346"),
  ("wicak", "Jakarta","1971-02-12","laki-laki","islam","kawin","petani","12342347"),
  ("eka widiawari", "bogor","1981-02-22","perempuan","islam","belum kawin","pns", "12342348"),
  ("mawar", "jogja","1990-03-11","perempuan","khatolik","kawin","nelayan", "12342349"),
  ("dani", "padang","1991-04-24","laki-laki","budha","kawin","pedagang", "12342355"),
  ("widodo", "makasar","1981-02-20","laki-laki","islam","belum kawin","nelayan","12342334"),
  ("nowo", "medan","1960-02-11","laki-laki","konghucu","kawin","pns","12342322"),
  ("prayoga", "lampung","1995-02-22","laki-laki","protestan","kawin","petani","12342311"),
  ("sulastri", "bantul","1994-03-26","perempuan","islam","kawin","tni/polri","12342305")
]

for val in values:
  cursor.execute(sql, val)
  konek.commit()

print("{} data ditambahkan".format(len(values)))

#nomer5
sql = "SELECT count(nik) FROM (SELECT (nik), TIMESTAMPDIFF(year, tanggal_lahir, curdate()) AS umur FROM uas_5180411007) AS DUMMY_TABLE WHERE umur>50 "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)

#nomer4
sql = "SELECT count(nik) FROM (SELECT (nik), pekerjaan FROM uas_5180411007 WHERE jenis_kelamin='laki-laki') AS DUMMY_TABLE WHERE pekerjaan='petani' OR pekerjaan='nelayan' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)