a=10
b=15
c=20
d=20
print(a+b+c+d)