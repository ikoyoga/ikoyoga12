#*****************************
# koneksi.py
# NIM   :518041107
# NAMA  :iko prayoga
#****************************
import mysql.connector
from mysql.connector import Error

konek = mysql.connector.connect(host='localhost',
                                  database='db_mahasiswa',
                                  user='root',
                                  password='')
  
#cek jika terjadi kesalahan
if konek.is_connected():
  print("terhubung")

cursor = konek.cursor()
# #nomer1
sql = "SELECT count(no_mahasiswa) FROM tb_mahasiswa WHERE jenis_kelamin='laki-laki' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)

# #nomer2
sql = "SELECT count(no_mahasiswa) FROM tb_mahasiswa WHERE jenis_kelamin='perempuan' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)
  
# #nomer3
sql = "SELECT count(no_mahasiswa) FROM tb_mahasiswa WHERE jenis_kelamin='laki-laki' AND jurusan='informatika' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)
  
 #nomer4
sql = "SELECT count(no_mahasiswa) FROM tb_mahasiswa WHERE jurusan='informatika' AND agama='islam' "
cursor.execute(sql)

results = cursor.fetchall()

for data in results:
  print(data)
  